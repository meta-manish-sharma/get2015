package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Business.Title;
import Connection.ConnectionUtil;

public class DatabaseHelper {
	
	
	//method return the list of the title objects which are published by given author
	public static ArrayList<Title> getBookPublishedByAuthor(String authorName){
		ArrayList<Title> titleList=new ArrayList<Title>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ConnectionUtil conUtil = new ConnectionUtil();
		con = conUtil.getConnection();
		
		String query = "select T.titleId,T.titleName from Title T JOIN Title_Author TA ON T.titleId=TA.titleId JOIN Authors A ON A.authorId=TA.authorId WHERE authorName= ? ";
		
	
		
		Title title=null;
		try {
			ps = con.prepareStatement(query);
			
			ps.setString(1,authorName);
		
			rs = ps.executeQuery();

			while (rs.next()) {
				
				title=new Title();
				title.setTitleId(rs.getInt(1));
				title.setTitleName(rs.getString(2));
				
				//adding the title object to list
				titleList.add(title);
			
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		
			try {
				if (con != null) {
					con.close();
				}
				if (ps != null) {
					ps.close();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}   

		}
		return titleList;
		
	}
	
	
	
	//method will return flag=0 if books is not issued other wise it will return flag=1
	public static int getStatusOfBookIssue(String bookName,int memberId){
		
		int flag=0;
		
		
		
		Connection con = null;
		PreparedStatement ps = null;
		
		ConnectionUtil conUtil = new ConnectionUtil();
		con = conUtil.getConnection();
		
		
		String query = "INSERT INTO Books_Issue (accessionNo,memberId) VALUES((SELECT accessionNo FROM Books B,Title T Where B.titleId=T.titleId AND T.titleName=? Limit 0,1 ),(Select memberId from Member Where memberId=?))";
		
		
		
		
		if(isTitlePresent(bookName)==true && isMemberPresent(memberId)==true){	
		

		try {
			ps = con.prepareStatement(query);
			//setting the parameter to query string
			ps.setString(1,bookName);
			ps.setInt(2,memberId);
		
			flag=ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		
			try {
				if (con != null) {
					con.close();
				}
				if (ps != null) { 
					ps.close();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return flag;
	}
		
		else{
			System.out.println("wrong member Id or Title Name");
			return 0;
		}
	}
	
	
	//return true if title present other wise will return false
	
	public static boolean isTitlePresent(String titleName){
		
		
		Boolean isTitlePresent=false;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement ps = null;
		
		ConnectionUtil conUtil = new ConnectionUtil();
		con = conUtil.getConnection();
		
		String query1="Select titleName from Title where titleName=?";
		
		try {
			ps = con.prepareStatement(query1);
			
			ps.setString(1,titleName);
		
			rs=ps.executeQuery();
			isTitlePresent= rs.next();
			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		
			try {
				if (con != null) {
					con.close();
				}
				if (ps != null) { 
					ps.close();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return isTitlePresent;
	}
	
	
	//return true if member already present otherwise return false
	public static Boolean isMemberPresent(int memberId){
		
		boolean  isMemberPresent=false;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement ps = null;
		
		ConnectionUtil conUtil = new ConnectionUtil();
		con = conUtil.getConnection();
		
		String query="Select memberId from Member where MemberId=?";
		
		try {
			ps = con.prepareStatement(query);
			
			ps.setInt(1,memberId);
			
			rs=ps.executeQuery();
			
			isMemberPresent=rs.next();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		
			try {
				if (con != null) {
					con.close();
				}
				if (ps != null) { 
					ps.close();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return isMemberPresent;
		
		
		
		
	}
	
	
	public static int toDeleteBooksNotIssuedInLastOneYear() {
		String query = "DELETE FROM B Using Books AS B WHERE(PERIOD_DIFF(DATE_FORMAT(CURDATE(), '%Y%m'),DATE_FORMAT((SELECT BI.issueDate FROM Books_Issue BI WHERE BI.accessionNo=B.accessionNo "
				+ "ORDER BY BI.issueDate DESC LIMIT 0,1), '%Y%m'))>12 OR (PERIOD_DIFF(DATE_FORMAT(CURDATE(), '%Y%m'),DATE_FORMAT(B.purchaseDate, '%Y%m') )>12 AND "
				+ " NOT EXISTS(SELECT BI.issueDate FROM Books_Issue BI WHERE BI.accessionNo=B.accessionNo ORDER BY BI.issueDate DESC LIMIT 0,1) ))";
		Connection connection = null;
		ConnectionUtil connectionUtil = new ConnectionUtil();
		connection = connectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int totalBooksDeleted = 0;
		try {
			preparedStatement = connection.prepareStatement(query);
			/* set variable in prepared statement */
			totalBooksDeleted = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			/* close connection */
			try {
				if (connection != null) {
					connection.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return totalBooksDeleted;
	}
	
	
	
	
	
}
